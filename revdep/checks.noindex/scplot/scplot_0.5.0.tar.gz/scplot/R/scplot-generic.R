#' @export
scplot <- function(object, ...) {
  UseMethod("scplot")
}
